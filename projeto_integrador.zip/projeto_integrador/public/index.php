<?php 

require_once __DIR__ . '/../app/core/Autoload.php';
require_once __DIR__ . '/../app/config/Config.php';

use app\core\Router;

$router = new Router();

$router->get('/', 'PlayerController@listAll');

// Player routes
$router->get('/jogadores', 'PlayerController@listAll');
$router->get('/jogadores/mostrar', 'PlayerController@show');
$router->get('/jogadores/criar', 'PlayerController@create');

$router->post('/jogadores/salvar', 'PlayerController@save');
$router->get('/jogadores/editar', 'PlayerController@edit');
$router->post('/jogadores/atualizar', 'PlayerController@update');
$router->get('/jogadores/deletar', 'PlayerController@delete');

$router->get('/teste', 'PlayerController@redirectTest');

$router->get('/users', 'UserController@index');
$router->get('/users/create', 'UserController@create');
$router->post('/users/store', 'UserController@store');

$router->get('/users/edit', 'UserController@edit');
$router->post('/users/update', 'UserController@update');

$router->get('/users/delete', 'UserController@delete');


$router->run();
