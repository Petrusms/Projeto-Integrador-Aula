<?php

namespace app\controllers;

use app\core\Controller;
use app\models\User;
use app\services\UserService;

class UserController extends Controller
{
    private UserService $service;

    public function __construct()
    {
        $this->service = new UserService();
    }

    public function index()
    {
        $data['usuarios'] = $this->service->getUsuarios();
        $this->view('users/user_list', $data);
    }

    public function create()
    {
        $this->view('users/user_create');
    }

    public function store()
    {
        $usuario = new User(
            0,
            $_POST['nomeUsuario'],
            $_POST['email'],
            $_POST['senha'],
            $_POST['perfil']
        );

        if ($this->service->saveUsuario($usuario)) {
            $this->redirect(URL_BASE . '/users');
        } else {
            echo "Este e-mail já está cadastrado NO SISTEMA!";
        }
    }


    public function edit()
    {
        $id = $_GET['id'];
        $data['usuario'] = $this->service->getUsuarioById($id);
        $this->view('users/user_edit', $data);
    }

    public function update()
    {
        $usuario = new User(
            $_POST['id'],
            $_POST['nomeUsuario'],
            $_POST['email'],
            $_POST['senha'] ?? '',
            $_POST['perfil']
        );
        $this->service->updateUsuario($usuario);
        $this->redirect(URL_BASE . '/users');
    }

    public function delete()
    {
        $id = $_GET['id'];
        $this->service->deleteUsuario($id);
        $this->redirect(URL_BASE . '/users');
    }
}
