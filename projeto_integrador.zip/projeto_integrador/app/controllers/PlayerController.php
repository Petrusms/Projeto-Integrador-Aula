<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Player;
use app\services\PlayerService;

class PlayerController extends Controller
{

    private PlayerService $service;

    public function __construct()
    {
        $this->service = new PlayerService();
    }

    public function listAll()
    {

        $data['lista'] = $this->service->getJogadores();

        $this->view('players/player_list', $data);
    }

    public function show()
    {

        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/players');
        }

        $id = $_GET['id'];

        $jogador['jogador'] = $this->service->getJogador($id);

        $this->view('players/player_show', $jogador);
    }

    public function create()
    {
        $this->view('players/player_create', []);
    }

    public function save()
    {
        $nome = $_POST['nome'];
        $nascimento = $_POST['dataNascimento'];
        $nacionalidade = $_POST['nacionalidade'];
        $altura = $_POST['altura'];
        $peso = $_POST['peso'];
        $peDominante = $_POST['peDominante'];
        $posicao = $_POST['posicao'];
        $time = $_POST['time'];
        $imagem = $_POST['imagem'] ?? '';


        $jogador = new Player();

        $jogador->setNome($nome);
        $jogador->setDataNascimento($nascimento);
        $jogador->setNacionalidade($nacionalidade);
        $jogador->setAltura($altura);
        $jogador->setPeso($peso);
        $jogador->setPeDominante($peDominante);
        $jogador->setPosicao($posicao);
        $jogador->setTime($time);
        $jogador->setImagem($imagem);

        //print_r($jogador);
        //exit;

        $this->service->saveJogador($jogador);
    }

    public function redirectTest()
    {
        $this->redirect("http://google.com");
    }
}
