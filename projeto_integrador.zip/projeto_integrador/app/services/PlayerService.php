<?php 

namespace app\services;

use app\models\Player;
use app\repositories\PlayerRepository;

class PlayerService {

    private PlayerRepository $repository;

    public function __construct(){

        $this->repository = new PlayerRepository();

    }

    public function getJogadores(){
        //se existisse a necessidade de uma validacao, ou verificacao, aqui seria o lugar correto
        return $this->repository->getJogadores();
    
    }

    public function getJogador(int $id){
        return $this->repository->getJogador($id);
    }

    public function saveJogador(Player $jogador){
        return $this->repository->saveJogador($jogador);
    }

}