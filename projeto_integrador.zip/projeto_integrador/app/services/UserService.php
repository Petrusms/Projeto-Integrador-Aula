<?php

namespace app\services;

use app\models\User;
use app\repositories\UserRepository;

class UserService
{
    private UserRepository $repository;

    public function __construct()
    {
        $this->repository = new UserRepository();
    }

    public function getUsuarios(): array
    {
        return $this->repository->getUsuarios();
    }

    public function saveUsuario(User $usuario): bool
    {
        // ve se o e-mail já está cadastrado
        $usuarioExistente = $this->repository->getUsuarioByEmail($usuario->getEmail());

        if ($usuarioExistente) {
            return false;
        }

        return $this->repository->saveUsuario($usuario);
    }
    public function updateUsuario(User $usuario): bool
    {
        return $this->repository->updateUsuario($usuario);
    }
    public function deleteUsuario(int $id): bool
    {
        return $this->repository->deleteUsuario($id);
    }
    public function getUsuarioById(int $id)
    {
        return $this->repository->getUsuarioById($id);
    }

    
}
